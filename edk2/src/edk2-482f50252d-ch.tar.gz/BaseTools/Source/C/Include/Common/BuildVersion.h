/** @file
This file is for build version number auto generation

Copyright (c) 2011 - 2018, Intel Corporation. All rights reserved.<BR>
SPDX-License-Identifier: BSD-2-Clause-Patent

**/

#define __BUILD_VERSION "Developer Build based on Revision: Unknown"
