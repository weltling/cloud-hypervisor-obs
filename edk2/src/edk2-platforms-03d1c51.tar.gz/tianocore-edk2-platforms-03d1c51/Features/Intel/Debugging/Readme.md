# **EDK II Minimum Platform Firmware Debug Advanced Features**

This feature domain directory contains debug related advanced features. Note that the domain directory is named
"Debugging" as opposed to "Debug" to help indicate that the directory is related to features used for debugging and it
is not an output directory for a Debug build target.

Features may be added to this domain whose primary role and responsibility is related to debug. The type of debug
technology may include hardware or software debug.
